<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Riverside Hospital Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
        }
        .dashboard-container {
            background: rgba(255, 255, 255, 0.1);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .dashboard-container h1 {
            margin-bottom: 20px;
            font-size: 2.5rem;
            font-weight: 600;
            color: #fff;
        }
        .dashboard-container h2 {
            margin-bottom: 30px;
            font-size: 1.5rem;
            font-weight: 400;
            color: #e0e0e0;
        }
        .dashboard-links {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .dashboard-links a {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            padding: 15px 20px;
            border-radius: 10px;
            text-decoration: none;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .dashboard-links a:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-3px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .dashboard-links a i {
            font-size: 1.2rem;
        }
        .logout-link {
            margin-top: 20px;
            color: #fff;
            text-decoration: none;
            font-size: 0.9rem;
            opacity: 0.8;
            transition: opacity 0.3s ease;
        }
        .logout-link:hover {
            opacity: 1;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h1>Riverside Hospital</h1>
        <h2>Welcome, <?php echo $_SESSION['username']; ?></h2>
        <div class="dashboard-links">
            <a href="nurse.html">
                <i class="fas fa-user-nurse"></i>
                NURSES/CLINICAL TECHNOLOGISTS TICKLIST
            </a>
            <a href="ro.html">
                <i class="fas fa-tint"></i>
                WATER TREATMENT ROOM
            </a>
            <a href="progress_sheet.html">
                <i class="fas fa-progress"></i>
                PATIENT PROGRESS SHEET
            </a>
            <a href="Riverside dialysis hospital Charge sheet.html">
                <i class="fas fa-file-invoice-dollar"></i>
                PATIENT CHARGE SHEET
            </a>
            <a href="Search Engines.html">

                <i class="fas fa-progress"></i>
                SEARCH ENGINE
            </a>
        </div>
        <a href="logout.php" class="logout-link">Logout</a>
    </div>
</body>
</html>